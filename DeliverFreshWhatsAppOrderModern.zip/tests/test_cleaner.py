from deliverfresh_whatsapp import clean_whatsapp_chat

def test_cleaning_sample():
    input_path = "test_input.txt"
    output_path = "test_output.txt"

    with open(input_path, "w") as f:
        f.write("2 kg Tomatoes\nThanks!\n1 box potatoes\nRaddish\n")

    clean_whatsapp_chat(input_path, output_path)

    with open(output_path) as f:
        lines = f.read().splitlines()

    assert "tomato" in lines
    assert "potato" in lines
    assert "radish" in lines
    assert "thanks" not in lines
